add lines of varying width and gradient ?
